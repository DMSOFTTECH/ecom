<!doctype html>
<!--[if lt IE 7]>
<html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>
<html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>
<html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="en">
<!--<![endif]-->

<head>

    <?php
    require_once(__DIR__ . "/modal/Card_Registration.php");
    if(isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on')
        $url = "https://";
    else
        $url = "http://";

    // Append the requested resource location to the URL
    $url.= $_SERVER['REQUEST_URI'];
    echo $url;
    $tess=   (explode(" ",$url));
    print_r($tess);
    $data=Card_Registration::allCards();
    //    $list=$data["list"];
    //    print_r($list);
    ?>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Details  | Digital Advertiser Visiting Card</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php require_once(__DIR__ . '/view/common_css.php') ?>

</head>

<body>



<?php require_once(__DIR__ . '/view/common_js.php'); ?>
</body>
</html>
