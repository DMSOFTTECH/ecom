<?php 
session_start();
ini_set('display_errors',E_ALL);
$con=mysqli_connect("localhost","root","","themart");
?>